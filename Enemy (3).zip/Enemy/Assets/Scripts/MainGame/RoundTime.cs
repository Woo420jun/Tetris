using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RoundTime : MonoBehaviour
{
    public Text playTimeText;
    public Text RemainingTimeText;
    public float RemainingTime;
    public float playTimeSecond;
    public float playTimeMinute;
    public float playTimeScale;
    //public PlayerTime playerTime;

    void Start()
    {
        DataManager.instance.playerTime.playTime = 0;
        RemainingTime = DataManager.instance.playerTime.remainTime;
        RemainingTimeText.text = "Remaining Time : " + RemainingTime;
    }

    public void StartTetrisGame()
    {
        DataManager.instance.playerTime.remainTime = RemainingTime;
        SceneManager.LoadSceneAsync(3);
        DataManager.instance.playerTime.tetrisPlayTime = DataManager.instance.playerTime.playTime;
        //playerTime.remainTime -= RemainingTime;
    }

    void PlayTimeTextOnGame()
    {
        playTimeScale = 0;
        playTimeMinute = 0;
        playTimeSecond = 0;

        for (playTimeScale = DataManager.instance.playerTime.playTime; 
            60 <= playTimeScale;
            playTimeScale -= 60)
        {
            playTimeMinute++;
        }

        if (playTimeScale < 60)
        {
            playTimeSecond += playTimeScale;
        }

        Debug.Log(playTimeMinute + "m" + playTimeSecond + "s");
        Debug.Log(playTimeScale + "Scale");

        playTimeText.text = playTimeMinute + " : " + playTimeSecond;
        RemainingTimeText.text = "Remaining Time : " + RemainingTime;
    }

    public void TimeScalePlus30()
    {
        if (RemainingTime >= 30)
        {
            DataManager.instance.playerTime.playTime += 30;
            RemainingTime -= 30;
            PlayTimeTextOnGame();
            Debug.Log(RemainingTime);
        }
    }

    public void TimeScalePlus5()
    {
        if (RemainingTime >= 5)
        {
            DataManager.instance.playerTime.playTime += 5;
            RemainingTime -= 5;
            PlayTimeTextOnGame();
            Debug.Log(RemainingTime);
        }
    }

    public void TimeScaleMinus30()
    {
        if (DataManager.instance.playerTime.playTime >= 30)
        {
            DataManager.instance.playerTime.playTime -= 30;
            RemainingTime += 30;
            PlayTimeTextOnGame();
            Debug.Log(RemainingTime);
        }
    }

    public void TimeScaleMinus5()
    {
        if (DataManager.instance.playerTime.playTime >= 5)
        {
            DataManager.instance.playerTime.playTime -= 5;
            RemainingTime += 5;
            PlayTimeTextOnGame();
            Debug.Log(RemainingTime);
        }
    }
}
