using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/UsedPositionMainGame")]

public class UsedPositionInMainGame : ScriptableObject
{
    public List<UsedPositionMainGame> usedPositionMainGameDatas = new List<UsedPositionMainGame>();
}

public class UsedPositionMainGame
{
    public GameObject prefab;
    public Vector2 position;
}
