using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EnemyInfo
{
    public string name;
    public float enemyFullHP;
    public GameObject enemyImage;
    public int PageNum;
    public BuffListData buffInfos;
}

[CreateAssetMenu(menuName = "Tetris/EnemyINFO")]
public class EnemyInformation : ScriptableObject
{
    public List<EnemyInfo> enemyINFODatas = new List<EnemyInfo>();

    public EnemyInfo GetRandomEnemy() => enemyINFODatas[Random.Range(0, enemyINFODatas.Count)];
}