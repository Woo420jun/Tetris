using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BuffInfo
{
    public int buff;
}

[System.Serializable]
public class DeBuffInfo
{
    public int debuuff;
}

[CreateAssetMenu(menuName = "Tetris/BuffListData")]
public class BuffListData : ScriptableObject
{
    public List<BuffInfo> buffInfoDatas = new List<BuffInfo>();
    public List<DeBuffInfo> deBuffInfoDatas = new List<DeBuffInfo>();
}