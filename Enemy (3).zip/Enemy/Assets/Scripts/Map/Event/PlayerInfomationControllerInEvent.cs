using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerInfomationControllerInEvent : MonoBehaviour
{
    public int Hp;

    public void ControlHP()
    {
        
    }

    public void ControlMoney()
    {

    }

    public void ControlSkill()
    {

    }

    public void ControlTreasure()
    {

    }

    public void EnemyContact()
    {
        SceneManager.LoadSceneAsync(1);
    }
}
