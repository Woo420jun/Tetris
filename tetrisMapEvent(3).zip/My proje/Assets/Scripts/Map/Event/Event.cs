using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Event : MonoBehaviour
{
    public List<GameObject> eventList = new List<GameObject> ();

    public bool isEvent;

    void Start()
    {

    }

    void Update()
    {
        
    }
}
