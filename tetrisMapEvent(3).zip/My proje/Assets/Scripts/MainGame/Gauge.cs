using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gauge : MonoBehaviour
{
    public GameObject gauge;
    public float mainGaugeMax = 15;
    public float mainGauge = 0;
    public int magnificationGaugeMax = 10;
    public int magnificationGauge = 0;

    // Start is called before the first frame update
    void Start()
    {
        TetrisManager.Instance.gauge = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void CanAttack()
    {

    }

    public void UpGauge()
    {
        gauge.transform.localScale=new Vector3(1,mainGauge*0.05f,1);
    }

    public void OnBreakLine(int lineCount, int tspinCount)
    {
        if (mainGauge>=mainGaugeMax)
        {
            mainGauge-=mainGaugeMax;
            magnificationGauge++;
        }
    }
}
