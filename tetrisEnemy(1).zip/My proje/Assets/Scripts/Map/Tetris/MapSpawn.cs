using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapSpawn : MonoBehaviour
{
    public GameObject[] Tetrominoes;

    void Start()
    {
        NewTetris();
    }

    // Update is called once per frame
    public void NewTetris()
    {
        Instantiate(Tetrominoes[Random.Range(0, Tetrominoes.Length)], transform.position, Quaternion.identity);

    }

}
