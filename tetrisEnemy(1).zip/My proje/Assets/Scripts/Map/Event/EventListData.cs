using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/EventListData")]
public class EventListData : ScriptableObject
{
    public List<EventData> eventDatas = new List<EventData>();
    public List<EnemyData> enemyDatas = new List<EnemyData>();
}

public class EventData
{
    public GameObject prefab;
    public Vector2 position;
}

public class EnemyData
{
    public GameObject enemyLine;
    public Vector2 position;
}