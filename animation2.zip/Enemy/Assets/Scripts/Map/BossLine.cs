using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BossLine : MonoBehaviour
{
    public GameObject bossLine;
    public Vector2 bossPosition;

    private bool bossContact = false;

    void Start()
    {
        Instantiate(bossLine, bossPosition, Quaternion.identity);
    }

    void Update()
    {
        for (int i = 0; i < DataManager.instance.tetrisUsedposition.usedpositionDatas.Count; i++)
        {
            if (DataManager.instance.tetrisUsedposition.usedpositionDatas[i].position.y == 1 + bossPosition.y)
            {
                Debug.Log("boss contact");
                BossBattleStart();
                return;
            }
        }
    }

    public void BossBattleStart()
    {
        Time.timeScale = 1.0f;
        int randomEnemyNum = Random.Range(0, DataManager.instance.enemyInformation.enemyINFODatas.Count);

        DataManager.instance.enemyData.enemyHPData
            = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyHPData;

        DataManager.instance.enemyData.enemyFullHPData
            = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyFullHPData;

        DataManager.instance.enemyData.enemyDamageData
            = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyDamageData;

        DataManager.instance.enemyData.enemyImage
            = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyImage;

        DataManager.instance.enemyData.enemyName
            = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].name;

        DataManager.instance.enemyData.buffInfos
            = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].buffInfos;

        DataManager.instance.EventSpaceData.eventDatas.Clear();
        DataManager.instance.EventSpaceData.enemyDatas.Clear();

        DataManager.instance.enemyData.isBoss = true;

        SceneManager.LoadSceneAsync(2);

        bossContact = false;
    }
}
