using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class UsedPosition
{
    public GameObject prefab;
    public Vector2 position;
}

[CreateAssetMenu(menuName = "Tetris/UsedPositionMap")]
public class TetrisUsedPosition : ScriptableObject
{
    public List<UsedPosition> usedpositionDatas = new List<UsedPosition>();
}