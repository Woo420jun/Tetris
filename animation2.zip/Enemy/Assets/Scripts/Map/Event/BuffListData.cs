using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BuffInfo
{
    public int damageBuffPlus;
    public int damageBuffMultiply;
    public int damageBuffPercent;

    public int costBuffPlus;
    public int costBuffMultiply;
    public int costBuffPercent;

    public int HPBuffPlus;
    public int HPBuffMultiply;
    public int HPBuffPercent;

    public string buffName;
    public string buffEffect;
}

[System.Serializable]
public class DeBuffInfo
{
    public int damageDebuffMinus;     
    public int damageDebuffDivide;     
    public int damageDebuffPercent;

    public int costDebuffMinus;       
    public int costDebuffDivide;      
    public int costDebuffPercent;

    public int HPDebuffMinus;          
    public int HPDebuffDivide;         
    public int HPDebuffPercent; 

    public string deBuffName;
    public string deBuffEffect;
}

[CreateAssetMenu(menuName = "Tetris/BuffListData")]
public class BuffListData : ScriptableObject
{
    public List<BuffInfo> buffInfoDatas = new List<BuffInfo>();
    public List<DeBuffInfo> deBuffInfoDatas = new List<DeBuffInfo>();
}