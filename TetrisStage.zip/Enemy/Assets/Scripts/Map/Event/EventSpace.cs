using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventSpace : MonoBehaviour
{
    public GameObject prefab;
    public int numOfEvent = 5;
    public float minDistance = 1.0f;

    public List<Vector2> usedPositions = new List<Vector2>();

    //public List<GameObject> eventList = new List<GameObject>();
    public GameObject[] eventTap;

    private bool isEvent = false;

    void Start()
    {
        LaodPosition();
    }

    void Update()
    {
        EventStart();
    }

    private void LaodPosition()
    {
        if (DataManager.instance.EventSpaceData.eventDatas.Count > 0 
            && DataManager.instance.EventSpaceData.stageClear == false)
        {
            foreach (var prefabData in DataManager.instance.EventSpaceData.eventDatas)
            {
                Instantiate(prefabData.prefab, prefabData.position, Quaternion.identity);
                usedPositions.Add(prefabData.position);
            }
        }
        else
        {
            int cnt = 0;

            while (cnt < numOfEvent)
            {
                Vector2 randomPosition = new Vector2(Random.Range(0, 12), Random.Range(0, 15));

                if (IsPositionValid(randomPosition))
                {
                    Instantiate(prefab, randomPosition, Quaternion.identity);
                    usedPositions.Add(randomPosition);
                    cnt++;

                    EventData newData = new EventData();
                    newData.position = randomPosition;
                    newData.prefab = prefab;
                    DataManager.instance.EventSpaceData.eventDatas.Add(newData);
                    Debug.Log(newData.position);
                }
            }
        }
    }

    private bool IsPositionValid(Vector2 position)
    {
        foreach (Vector2 usedPosition in usedPositions)
        {
            if (Vector2.Distance(position, usedPosition) < minDistance)
            {
                return false;
            }
        }
        return true;
    }

    public void EventActivate(int x, int y)
    {
        for (int i = 0; i < usedPositions.Count; i++)
        {
            if (x == usedPositions[i].x && y == usedPositions[i].y)
            {
                Debug.Log("Event Start");
                usedPositions.RemoveAt(i);
                DataManager.instance.EventSpaceData.eventDatas.RemoveAt(i);
                isEvent = true;
            }
        }
    }

    public void EventStart()
    {
        if (isEvent == true)
        {
            Debug.Log("Event!!!");
            Time.timeScale = 0f;
            GameObject randomObject = eventTap[Random.Range(0, eventTap.Length)];
            randomObject.SetActive(true);
            isEvent = false;
        }
    }
}
