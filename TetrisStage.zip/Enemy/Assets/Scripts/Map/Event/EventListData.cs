using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EventData
{
    public GameObject prefab;
    public Vector2 position;
}

[System.Serializable]
public class EnemyData
{
    public GameObject enemyLine;
    public Vector2 position;
}

[CreateAssetMenu(menuName = "Tetris/EventListData")]
public class EventListData : ScriptableObject
{
    public List<EventData> eventDatas = new List<EventData>();
    public List<EnemyData> enemyDatas = new List<EnemyData>();
    public bool stageClear = false;
}
