using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    // hp , skill , 
    public int Life;
    public GameObject skill;

    void Start()
    {
        Life = 3 + DataManager.instance.PlayerInformationData.LifeValue;
        Debug.Log(Life);
    }

    void Update()
    {
        PlayerDead();
    }

    void PlayerDead()
    {
        if (0 >= Life)
        {
            SceneManager.LoadSceneAsync(1);
        }
    }
}
