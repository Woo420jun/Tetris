using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EnemyInfo
{
    public int tier;
    public GameObject enemyImage;
    public string name;
    public float enemyFullHPData;
    public float enemyHPData;
    public BuffListData buffInfos;
}

[CreateAssetMenu(menuName = "Tetris/EnemyINFO")]
public class EnemyInformation : ScriptableObject
{
    public List<EnemyInfo> enemyINFODatas = new List<EnemyInfo>();

    public EnemyInfo GetRandomEnemy() => enemyINFODatas[Random.Range(0, enemyINFODatas.Count)];
}