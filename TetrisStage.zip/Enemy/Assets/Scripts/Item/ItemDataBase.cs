using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemDataBase : MonoBehaviour
{
    //public static List<Item.ItemData> itemList = new List<Item.ItemData> ();

    void Awake ()
    {
        //itemList.Add(new Item(0, "None", 0, 0, 0, 0, "None"));// ID, Name, , , ItemDescriotion
    }
}
