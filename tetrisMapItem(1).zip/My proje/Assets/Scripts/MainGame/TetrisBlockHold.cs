using System.Collections;
using System.Collections.Generic;
using TetrisControl;
using Unity.VisualScripting;
using UnityEngine;

public class TetrisBlockHold : MonoBehaviour
{
    bool canHold = true;
    TetrisBlockMover holdBag;

    [SerializeField] Transform holdBasis;

    private ESC esc;

    void Start()
    {
        esc = FindObjectOfType<ESC>();
    }
    public void Awake()
    {
        TetrisManager.Instance.blockHold = this;
    }
    public void Update()
    {
        if (!esc.showEscMenu)
        {
            HoldBlock();
        }
    }
    public void SetCanHold()
    {
        canHold = true;
    }

    void HoldBlock()
    {
        if (Input.GetKeyDown(KeyCode.A) && canHold)
        {
            canHold = false;
            if (holdBag != null)
            {
                var tempBag = holdBag;
                holdBag.transform.position = TetrisManager.Instance.spawn.GetSpawnPosition(holdBag.blockType);
                holdBag.enabled = true;
                holdBag.transform.rotation = Quaternion.identity;
                holdBag.tetrisSRS.currentRotation = 0;

                holdBag = TetrisManager.Instance.currentBlock;
                holdBag.transform.position = holdBasis.position;
                holdBag.transform.rotation = Quaternion.identity;
                holdBag.enabled = false;

                TetrisManager.Instance.currentBlock = tempBag;
            }
            else
            {
                holdBag = TetrisManager.Instance.currentBlock;
                holdBag.transform.position = holdBasis.position;
                holdBag.transform.rotation = Quaternion.identity;
                holdBag.enabled = false;
                TetrisManager.Instance.spawn.NewTetris();
            }
        }
    }
}
