using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/EventListData")]
public class EventListData : ScriptableObject
{
    public List<EventData> eventDatas = new List<EventData>();
}

public class EventData
{
    public GameObject prefab;
    public Vector2 position;
}