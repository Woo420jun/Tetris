using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class Gauge : MonoBehaviour
{
    //Gauge
    public Slider gauge;
    public Slider enemyHPSlider;
    public Slider playerHPSlider;

    public int mainGaugeMax = 15;
    public int mainGauge = 0;
    public int magnificationGaugeMax = 10;
    public int magnificationGauge = 0;

    public GameObject fill;

    //Skill
    private bool canAttack;
    public bool showSkillTap;
    private bool attacked;

    public GameObject skillTap;
    public GameObject FirstSelect;

    public Text gaugeText;
    public Text costText;
    public Text enemyHPText;
    public Text enemyNameText;
    public Text playerHPText;
    public Text playerNameText;

    public GameObject SkillNum1;
    public GameObject SkillNum2;
    public GameObject SkillNum3;
    public GameObject SkillNum4;

    public Skill skillList;

    public int cost;
    public int skillCost;
    public float attackPower;
    public float defaultValue;
    public float SkillPower;
    private bool hasExecuted = true;

    //Enemy
    public float enemyHP;
    public float enemyFullHP;
    public GameObject enemyImage;

    //Time
    public Text timeText;


    void Start()
    {
        TetrisManager.Instance.gauge = this;

        attackPower = 0;
        //attacked = false;
        //canAttack = false;

        gauge.maxValue = mainGaugeMax;

        showSkillTap = false;
        skillTap.SetActive(false);

        enemyHP = DataManager.instance.enemyData.enemyHPData;
        enemyFullHP = DataManager.instance.enemyData.enemyFullHPData;
        enemyImage = DataManager.instance.enemyData.enemyImage;
        enemyNameText.text = DataManager.instance.enemyData.enemyName;

        playerNameText.text = DataManager.instance.playerINFO.playerName;

        UpdateSkills();
        EnemyHPViewer();
        PlayerHPViewer();
        StartCoroutine(GameRoutine());
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            CloseSkillTap();
        }

        gaugeText.text = magnificationGauge + "X";
        costText.text = "COST." + cost;

        GaugeControl();
        CanAttack();

        // for test
        if (Input.GetKeyDown(KeyCode.P))
        {
            ++cost;
            ++magnificationGauge;
        }// for test
    }

    public void UpdateSkills()
    {
        if (skillList != null && skillList.Skills != null)
        {
            if (SkillNum1 != null)
            {
                Text skillText1 = SkillNum1.GetComponent<Text>();
                if (skillText1 != null && skillList.Skills.Length > 0)
                {
                    SkillInformation skillInfo1 = skillList.Skills[0].GetComponent<SkillInformation>();
                    if (skillInfo1 != null)
                    {
                        skillText1.text = skillInfo1.skillName;
                    }
                }
            }

            if (SkillNum2 != null)
            {
                Text skillText2 = SkillNum2.GetComponent<Text>();
                if (skillText2 != null && skillList.Skills.Length > 1)
                {
                    SkillInformation skillInfo2 = skillList.Skills[1].GetComponent<SkillInformation>();
                    if (skillInfo2 != null)
                    {
                        skillText2.text = skillInfo2.skillName;
                    }
                }
            }

            if (SkillNum3 != null)
            {
                Text skillText3 = SkillNum3.GetComponent<Text>();
                if (skillText3 != null && skillList.Skills.Length > 2)
                {
                    SkillInformation skillInfo3 = skillList.Skills[2].GetComponent<SkillInformation>();
                    if (skillInfo3 != null)
                    {
                        skillText3.text = skillInfo3.skillName;
                    }
                }
            }

            if (SkillNum4 != null)
            {
                Text skillText4 = SkillNum4.GetComponent<Text>();
                if (skillText4 != null && skillList.Skills.Length > 3)
                {
                    SkillInformation skillInfo4 = skillList.Skills[3].GetComponent<SkillInformation>();
                    if (skillInfo4 != null)
                    {
                        skillText4.text = skillInfo4.skillName;
                    }
                }
            }
        }
    }

    public void ActiveSkill1()
    {
        SkillInformation skillInfo1 = skillList.Skills[0].GetComponent<SkillInformation>();

        if (cost >= skillInfo1.skillCost)
        {
            cost -= skillInfo1.skillCost;
            attackPower += skillInfo1.skillPower;
            attackPower *= magnificationGauge;

            SkillBuff();

            DataManager.instance.enemyData.enemyHPData -= attackPower;
            attackPower = 0;
            //attacked = true;
            EnemyHPViewer();
            PlayerHPViewer();

            EnemyDead();
        }
    }

    public void ActiveSkill2()
    {
        SkillInformation skillInfo2 = skillList.Skills[1].GetComponent<SkillInformation>();
        if (cost >= skillInfo2.skillCost)
        {
            cost -= skillInfo2.skillCost;
            attackPower += skillInfo2.skillPower;
            attackPower *= magnificationGauge;

            SkillBuff();

            DataManager.instance.enemyData.enemyHPData -= attackPower;
            attackPower = 0;
            //attacked = true;
            EnemyHPViewer();
            PlayerHPViewer();

            EnemyDead();
        }
    }

    public void ActiveSkill3()
    {
        SkillInformation skillInfo3 = skillList.Skills[2].GetComponent<SkillInformation>();
        if (cost >= skillInfo3.skillCost)
        {
            cost -= skillInfo3.skillCost;
            attackPower += skillInfo3.skillPower;
            attackPower *= magnificationGauge;

            SkillBuff();

            DataManager.instance.enemyData.enemyHPData -= attackPower;
            attackPower = 0;
            //attacked = true;

            EnemyHPViewer();
            PlayerHPViewer();

            EnemyDead();
        }
    }

    public void ActiveSkill4()
    {
        SkillInformation skillInfo4 = skillList.Skills[3].GetComponent<SkillInformation>();
        if (cost < skillInfo4.skillCost)
        {
            cost -= skillInfo4.skillCost;
            attackPower += skillInfo4.skillPower;
            attackPower *= magnificationGauge;

            SkillBuff();

            DataManager.instance.enemyData.enemyHPData -= attackPower;
            attackPower = 0;
            //attacked = true;

            EnemyHPViewer();
            PlayerHPViewer();

            EnemyDead();
        }
    }

    IEnumerator GameRoutine()
    {
        float timeTextScale = DataManager.instance.playerTime.tetrisPlayTime;
        while(timeTextScale > 0)
        {
            timeTextScale -= Time.deltaTime;
            yield return null;
            timeText.text = (int)timeTextScale + " Second";
        }

        attackPower = magnificationGauge;
        skillTap.SetActive(true);
        showSkillTap = true;
        EventSystem.current.SetSelectedGameObject(FirstSelect);
        timeText.text = "0 Second";
    }

    public void CanAttack()
    {
        if (DataManager.instance.playerTime.tetrisPlayTime < 1 && hasExecuted)
        {
            Debug.Log("before receiving buff or debuff: " + cost);
            attackPower = magnificationGauge;
            CostBuff();
            Debug.Log("after receiving buff or debuff: " + cost);
            skillTap.SetActive(true);
            showSkillTap = true;
            EventSystem.current.SetSelectedGameObject(FirstSelect);
            DataManager.instance.playerTime.playTime = 0;

            hasExecuted = false; 
        }

        //if (magnificationGauge > 0)
        //{
        //    canAttack = true;
        //}

        //if (canAttack == true)
        //{
        //    attackPower = magnificationGauge;
        //    skillTap.SetActive(true);
        //    showSkillTap = true;
        //    EventSystem.current.SetSelectedGameObject(FirstSelect);
        //}
    }

    public void OnBreakLine(int deleteCount, int tspinCount)
    {
        if (DataManager.instance.pageBuffINFO.costBuffMultiply != 0)
            deleteCount *= DataManager.instance.pageBuffINFO.costBuffMultiply;

        mainGauge += deleteCount;//Plus 1 gauge, If breaked tetris line 
        cost += deleteCount;

        if (mainGauge>=mainGaugeMax)
        {
            mainGauge-=mainGaugeMax;
            magnificationGauge++;
        }
        gauge.value = mainGauge;
    }

    public void GaugeControl()
    {
        if (mainGauge == 0)
        {
            fill.SetActive(false);
        }
        else
        {
            fill.SetActive(true);
        }
    }

    public void CloseSkillTap()
    {
        HPDebuff();

        if (DataManager.instance.enemyData.pageNum <= 0)
        {
            DataManager.instance.playerINFO.playerHP -= DataManager.instance.enemyData.enemyDamageData;

            if (DataManager.instance.playerINFO.playerHP > 0)
            {
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;
            }
            else
            {
                SceneManager.LoadSceneAsync(0);// !!CHANGE GAME OVER SCENE!!
                Time.timeScale = 1.0f;
            }
        }
        else
        {
            DataManager.instance.enemyData.pageNum--;

            SceneManager.LoadSceneAsync(2);
            Time.timeScale = 1.0f;
        }
        //skillTap.SetActive(false);
        //showSkillTap = false;
        //if (attacked == true)
        //{
        //    magnificationGauge = 0;
        //    attacked = false;
        //}
    }

    public void EnemyHPViewer()
    {
        enemyHPText.text = DataManager.instance.enemyData.enemyHPData + "/" + enemyFullHP;
        enemyHPSlider.maxValue = enemyFullHP;
        enemyHPSlider.value = DataManager.instance.enemyData.enemyHPData;
    }

    public void PlayerHPViewer()
    {
        playerHPText.text = DataManager.instance.playerINFO.playerHP + "/" + DataManager.instance.playerINFO.playerMaxHP;
        playerHPSlider.maxValue = DataManager.instance.playerINFO.playerMaxHP;
        playerHPSlider.value = DataManager.instance.playerINFO.playerHP;
    }

    public void EnemyDead()
    {
        if (DataManager.instance.enemyData.enemyHPData <= 0)
        {
            HPBuff();

            if (DataManager.instance.enemyData.isBoss == true)
            {
                DataManager.instance.enemyData.isBoss = false;
                DataManager.instance.EventSpaceData.stageClear = true;
                DataManager.instance.EventSpaceData.eventDatas.Clear();
                DataManager.instance.tetrisUsedposition.usedpositionDatas.Clear();
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;

                DataManager.instance.playerTime.remainTime = DataManager.instance.playerTime.MaxTime;
            }
            else
            {
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;

                DataManager.instance.playerTime.remainTime = DataManager.instance.playerTime.MaxTime;
            }
        }
    }

    public void SkillBuff()
    {
        //buff
        if (DataManager.instance.pageBuffINFO.damageBuffPlus != 0)
            attackPower += DataManager.instance.pageBuffINFO.damageBuffPlus;

        if (DataManager.instance.pageBuffINFO.damageBuffMultiply != 0)
            attackPower *= DataManager.instance.pageBuffINFO.damageBuffMultiply;

        if (DataManager.instance.pageBuffINFO.damageBuffPercent != 0)
            attackPower += attackPower * DataManager.instance.pageBuffINFO.damageBuffPercent / 100;

        //debuff
        if (DataManager.instance.pageBuffINFO.damageDebuffMinus != 0)
            attackPower -= DataManager.instance.pageBuffINFO.damageDebuffMinus;

        if (DataManager.instance.pageBuffINFO.damageDebuffDivide != 0)
            attackPower /= DataManager.instance.pageBuffINFO.damageDebuffDivide;

        if (DataManager.instance.pageBuffINFO.damageDebuffPercent != 0)
            attackPower -= attackPower * DataManager.instance.pageBuffINFO.damageDebuffPercent / 100;
    }

    public void CostBuff()
    {
        //buff
        if (DataManager.instance.pageBuffINFO.costBuffPlus != 0)
            cost += DataManager.instance.pageBuffINFO.costBuffPlus;

        if (DataManager.instance.pageBuffINFO.costBuffPercent != 0)
            cost += cost * DataManager.instance.pageBuffINFO.costBuffPercent / 100;

        //debuff
        if (DataManager.instance.pageBuffINFO.costDebuffMinus != 0)
            cost -= DataManager.instance.pageBuffINFO.costDebuffMinus;

        if (DataManager.instance.pageBuffINFO.costDebuffDivide != 0)
            cost /= DataManager.instance.pageBuffINFO.costDebuffDivide;

        if (DataManager.instance.pageBuffINFO.costDebuffPercent != 0)
            cost -= cost * DataManager.instance.pageBuffINFO.costDebuffPercent / 100;
    }

    public void HPBuff()
    {
        //buff
        if (DataManager.instance.pageBuffINFO.HPBuffPlus != 0)
            DataManager.instance.playerINFO.playerHP += DataManager.instance.pageBuffINFO.HPBuffPlus;

        if (DataManager.instance.pageBuffINFO.HPBuffMultiply != 0)
            DataManager.instance.playerINFO.playerHP *= DataManager.instance.pageBuffINFO.HPBuffMultiply;

        if (DataManager.instance.pageBuffINFO.HPBuffPercent != 0)
            DataManager.instance.playerINFO.playerHP += DataManager.instance.playerINFO.playerHP * DataManager.instance.pageBuffINFO.HPBuffPercent / 100;
    }

    public void HPDebuff()
    {
        //debuff
        if (DataManager.instance.pageBuffINFO.HPDebuffMinus != 0)
            DataManager.instance.playerINFO.playerHP -= DataManager.instance.pageBuffINFO.HPDebuffMinus;

        if (DataManager.instance.pageBuffINFO.HPDebuffDivide != 0)
            DataManager.instance.playerINFO.playerHP /= DataManager.instance.pageBuffINFO.HPDebuffDivide;

        if (DataManager.instance.pageBuffINFO.HPDebuffPercent != 0)
            DataManager.instance.playerINFO.playerHP -= DataManager.instance.playerINFO.playerHP * DataManager.instance.pageBuffINFO.HPDebuffPercent / 100;
    }
}
//There's a bug with the cost part and infinite loading when the enemy is killed.