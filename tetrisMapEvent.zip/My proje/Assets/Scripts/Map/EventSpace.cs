using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public class EventSpace : MonoBehaviour
{
    public EventListData EventSpaceData; 
    public GameObject prefab;
    public int numOfEvent = 5;
    public float minDistance = 1.0f;

    public List<Vector2> usedPositions = new List<Vector2>();

    public GameObject eventTap;
    public bool openedEventTap;



    void Start()
    {
        //openedEventTap = false;
        //eventTap.SetActive(false);
        LaodPosition();
        DebugPosition();
    }

    private void LaodPosition()
    {
        if (EventSpaceData.eventDatas.Count > 0)
        {
            foreach (var prefabData in EventSpaceData.eventDatas)
            {
                Instantiate(prefabData.prefab, prefabData.position, Quaternion.identity);
                usedPositions.Add(prefabData.position);
                Debug.Log(prefabData.position);

            }
        }
        else
        {
            int cnt = 0;

            while (cnt < numOfEvent)
            {
                Vector2 randomPosition = new Vector2(Random.Range(0, 12), Random.Range(0, 15));

                if (IsPositionValid(randomPosition))
                {
                    Instantiate(prefab, randomPosition, Quaternion.identity);
                    usedPositions.Add(randomPosition);
                    cnt++;

                    Debug.Log("running");

                    EventData newData = new EventData();
                    newData.position = randomPosition;
                    newData.prefab = prefab;
                    EventSpaceData.eventDatas.Add(newData);
                }
            }
        }
    }


    private bool IsPositionValid(Vector2 position)
    {
        foreach(Vector2 usedPosition in usedPositions)
        {
            if (Vector2.Distance(position, usedPosition) < minDistance)
            {
                return false;
            }
        }
        return true;
    }

    void DebugPosition()
    {
        for (int i = 0; i < EventSpaceData.eventDatas.Count; i++)
        {
            var data = EventSpaceData.eventDatas[i];
            Debug.Log(data.position);

        }
    }
    private void OnCollisionStay2D(Collision2D collision)
    {
        eventTap.SetActive(true);
        openedEventTap=true;
    }

    public void EventActivate()
    {
    }
}
