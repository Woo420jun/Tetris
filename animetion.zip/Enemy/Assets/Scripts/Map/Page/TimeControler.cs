using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class TimeControler : MonoBehaviour
{
    public float timeLate = 3f;
    public float tetrisPlayTime;
    public bool pause = true;

    void Start()
    {
        //Invoke(nameof(UnPause), timeLate);
        //Invoke(nameof(TimeOver), tetrisPlayTime);
    }

    private void UnPause()
    {
        pause = false;
        FindAnyObjectByType<TetrisSpawn>().Spawn();
    }

    private void TimeOver()
    {
        pause = false;
        FindAnyObjectByType<Gauge>().CanAttack();
    }
}
