using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Page : MonoBehaviour
{
    public GameObject hidePage;
    public GridLayoutGroup gridLayoutGroup;
    public Text buffText;
    public Text debuffText;
    void Start()
    {
        DataManager.instance.pageBuffINFO.DataClear();

        Debug.Log(DataManager.instance.enemyData.pageNum);

        for (int i = 0; i < DataManager.instance.enemyData.pageNum - 1; i++)
        {
            Instantiate(hidePage, gridLayoutGroup.transform);
        }

        int buffIndex = Random.Range(0, DataManager.instance.enemyData.buffInfos.buffInfoDatas.Count);
        int debuffIndex = Random.Range(0, DataManager.instance.enemyData.buffInfos.deBuffInfoDatas.Count);

        // Buff 
        var selectedBuff = DataManager.instance.enemyData.buffInfos.buffInfoDatas[buffIndex];

        DataManager.instance.pageBuffINFO.damageBuffPlus = selectedBuff.damageBuffPlus;
        DataManager.instance.pageBuffINFO.damageBuffMultiply = selectedBuff.damageBuffMultiply;
        DataManager.instance.pageBuffINFO.damageBuffPercent = selectedBuff.damageBuffPercent;

        DataManager.instance.pageBuffINFO.costBuffPlus = selectedBuff.costBuffPlus;
        DataManager.instance.pageBuffINFO.costBuffMultiply = selectedBuff.costBuffMultiply;
        DataManager.instance.pageBuffINFO.costBuffPercent = selectedBuff.costBuffPercent;

        DataManager.instance.pageBuffINFO.HPBuffPlus = selectedBuff.HPBuffPlus;
        DataManager.instance.pageBuffINFO.HPBuffMultiply = selectedBuff.HPBuffMultiply;
        DataManager.instance.pageBuffINFO.HPBuffPercent = selectedBuff.HPBuffPercent;

        DataManager.instance.pageBuffINFO.buffName = selectedBuff.buffName;
        DataManager.instance.pageBuffINFO.buffEffect = selectedBuff.buffEffect;

        // Debuff 
        var selectedDebuff = DataManager.instance.enemyData.buffInfos.deBuffInfoDatas[debuffIndex];

        DataManager.instance.pageBuffINFO.damageDebuffMinus = selectedDebuff.damageDebuffMinus;
        DataManager.instance.pageBuffINFO.damageDebuffDivide = selectedDebuff.damageDebuffDivide;
        DataManager.instance.pageBuffINFO.damageDebuffPercent = selectedDebuff.damageDebuffPercent;

        DataManager.instance.pageBuffINFO.costDebuffMinus = selectedDebuff.costDebuffMinus;
        DataManager.instance.pageBuffINFO.costDebuffDivide = selectedDebuff.costDebuffDivide;
        DataManager.instance.pageBuffINFO.costDebuffPercent = selectedDebuff.costDebuffPercent;

        DataManager.instance.pageBuffINFO.HPDebuffMinus = selectedDebuff.HPDebuffMinus;
        DataManager.instance.pageBuffINFO.HPDebuffDivide = selectedDebuff.HPDebuffDivide;
        DataManager.instance.pageBuffINFO.HPDebuffPercent = selectedDebuff.HPDebuffPercent;

        DataManager.instance.pageBuffINFO.deBuffName = selectedDebuff.deBuffName;
        DataManager.instance.pageBuffINFO.deBuffEffect = selectedDebuff.deBuffEffect;
    }
}
