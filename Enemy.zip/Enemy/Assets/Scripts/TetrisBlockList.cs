using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/TetrisBlockList")]
public class TetrisBlockList : ScriptableObject
{
    [SerializeField]
    GameObject[] tetrisBlocks;
    public GameObject[] Blocks => tetrisBlocks;
}
