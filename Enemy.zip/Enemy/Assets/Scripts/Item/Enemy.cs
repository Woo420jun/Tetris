using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/EnemyData")]
public class Enemy : ScriptableObject
{
    [SerializeField]
    GameObject[] tetrisBlocks;
    public GameObject[] Enemies => tetrisBlocks;
}
