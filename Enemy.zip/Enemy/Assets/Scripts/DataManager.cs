using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataManager : MonoBehaviour
{
    public static DataManager instance;
    public EventSpace eventSpace;
    public EventListData EventSpaceData;
    public ItemDataBase itemDataBase;
    public Gauge gauge;
    public Skill skill;
    public TetrisUsedPosition tetrisUsedposition;
    public PlayerTime playerTime;

    public EnemyLine enemyLine; 
    public Enemy enemyData;
    public EnemyInformation enemyInformation;

    public PlayerData PlayerInformationData;

    void Awake()
    {
        if (instance == null) 
        {
            instance = this;
        }
    }

}
