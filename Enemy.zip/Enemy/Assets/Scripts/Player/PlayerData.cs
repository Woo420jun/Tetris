using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/PlayerInformationData")]

public class PlayerData : ScriptableObject
{
    public int LifeValue = 3;
    public int MoneyValue;
    public int GaugeValue;

    public List<PlayerTreasureData> playerTreasureData = new List<PlayerTreasureData>();
    public List<PlayerSkillData> playerSkill = new List<PlayerSkillData>();
}

public class PlayerTreasureData
{

}

public class PlayerSkillData
{

}
