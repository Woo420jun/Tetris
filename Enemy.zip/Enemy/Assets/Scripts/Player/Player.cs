using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Player/Player")]
public class Player : ScriptableObject
{
    public int playerHP;
    public int playerMaxHP;
    public int money;

    public string playerName;
}