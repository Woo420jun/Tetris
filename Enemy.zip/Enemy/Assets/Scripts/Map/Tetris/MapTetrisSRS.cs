using UnityEngine;

namespace TetrisControl
{
    public class MapTetrisSRS : MonoBehaviour
    {
        const float blockMove = 1f; // Power to move the Tetris block
        public int currentRotation = 0; //
        public Vector3 rotationPoint;
        const int RotationStateCount = 4;



        public enum SuperRotationType
        {
            Normal,
            IBlock,
        }

        public enum RotationDirection
        {
            Left,
            Right
        }

        TetrisMoverInMap moveMap;

        public SuperRotationType rotationType;

        readonly Vector3[,] SRSNormalTypeLeft =
        {
            //{
            //    ? > A
            //    ? > B
            //    ? > C
            //    ? > D
            //}

            //Step1�F���݂̏�Ԃɂ�荶�E�ɂP?�X
            {
                new Vector3(blockMove, 0, 0),
                new Vector3(-blockMove, 0, 0),
                new Vector3(-blockMove, 0, 0),
                new Vector3(blockMove, 0, 0)
            },
            //Step2�F���݂̏�Ԃɂ��Step�P?�㉺�ɂP?�X
            {
                new Vector3(blockMove, -blockMove, 0),
                new Vector3(-blockMove, blockMove, 0),
                new Vector3(-blockMove, -blockMove, 0),
                new Vector3(blockMove, blockMove, 0)
            },
            //Step3�F���݂̏�Ԃɂ��㉺�ɂQ?�X
            {
                new Vector3(0, blockMove * 2, 0),
                new Vector3(0, -blockMove * 2, 0),
                new Vector3(0, blockMove * 2, 0),
                new Vector3(0, -blockMove * 2, 0)
            },
            //Step�S�F���݂̏�Ԃɂ��Step�R?���E�ɂP?�X
            {
                new Vector3(blockMove,  blockMove * 2, 0),
                new Vector3(-blockMove, -blockMove * 2, 0),
                new Vector3(-blockMove, blockMove * 2, 0),
                new Vector3(blockMove,  -blockMove * 2, 0)
            },
        };

        readonly Vector3[,] SRSNormalTypeRight =
        {
            {
                new Vector3(-blockMove, 0, 0),
                new Vector3(-blockMove, 0, 0),
                new Vector3(blockMove, 0, 0),
                new Vector3(blockMove, 0, 0)
            },
            {
                new Vector3(-blockMove, -blockMove, 0),
                new Vector3(-blockMove, blockMove, 0),
                new Vector3(blockMove, -blockMove, 0),
                new Vector3(blockMove, blockMove, 0)
            },
            {
                new Vector3(0, blockMove * 2, 0),
                new Vector3(0, -blockMove * 2, 0),
                new Vector3(0, blockMove * 2, 0),
                new Vector3(0, -blockMove * 2, 0)
            },
            {
                new Vector3(-blockMove,  blockMove * 2, 0),
                new Vector3(-blockMove, -blockMove * 2, 0),
                new Vector3(blockMove, blockMove * 2, 0),
                new Vector3(blockMove,  -blockMove * 2, 0)
            },
        };
        readonly Vector3[,] SRSNormalTypeIBlockLeft =
        {
            {
                new Vector3(blockMove * 2, 0, 0),
                new Vector3(blockMove, 0, 0),
                new Vector3(blockMove, 0, 0),
                new Vector3(-blockMove, 0, 0)
            },
            {
                new Vector3(-blockMove, 0, 0),
                new Vector3(blockMove * 2, 0, 0),
                new Vector3(-blockMove * 2, 0, 0),
                new Vector3(blockMove * 2, 0, 0)
            },
            {
                new Vector3(blockMove * 2, blockMove * 2, 0),
                new Vector3(blockMove * 2, -blockMove * 2, 0),
                new Vector3(-blockMove * 2, -blockMove * 2, 0),
                new Vector3(-blockMove, blockMove * 2, 0)
            },
            {
                new Vector3(-blockMove, -blockMove * 2, 0),
                new Vector3(-blockMove, -blockMove * 2, 0),
                new Vector3(-blockMove * 2, blockMove, 0),
                new Vector3(blockMove * 2,  -blockMove, 0)
            },
        };
        readonly Vector3[,] SRSNormalTypeIBlockRight =
        {
            {
                new Vector3(-blockMove * 2, 0, 0),
                new Vector3(-blockMove * 2, 0, 0),
                new Vector3(-blockMove, 0, 0),
                new Vector3(blockMove * 2, 0, 0)
            },
            {
                new Vector3(blockMove, 0, 0),
                new Vector3(blockMove, 0, 0),
                new Vector3(blockMove * 2, 0, 0),
                new Vector3(-blockMove, 0, 0)
            },
            {
                new Vector3(blockMove, -blockMove * 2, 0),
                new Vector3(-blockMove * 2, -blockMove, 0),
                new Vector3(-blockMove, blockMove * 2, 0),
                new Vector3(blockMove * 2, blockMove, 0)
            },
            {
                new Vector3(-blockMove * 2, blockMove, 0),
                new Vector3(blockMove, blockMove * 2, 0),
                new Vector3(blockMove * 2, -blockMove, 0),
                new Vector3(-blockMove,-blockMove * 2, 0)
            },
        };
        public bool SRSTetrisBlock(RotationDirection direction)
        {
            //SRS���Ă��Ȃ�
            bool re = false;

            //��?�O�̏�Ԃ�ۑ�
            var oldPosition = transform.position;
            var oldRotation = transform.rotation;
            var oldRotationState = currentRotation;

            float directionSign = 1;
            //��?�����Ă݂�
            if (direction == RotationDirection.Left)
            {
                directionSign = 1;
                currentRotation--;
            }
            else if (direction == RotationDirection.Right)
            {
                directionSign = -1;
                currentRotation++;
            }
            if (currentRotation >= RotationStateCount)
            {
                currentRotation = currentRotation - RotationStateCount;
            }
            else if (currentRotation < 0)
            {
                currentRotation = RotationStateCount + currentRotation;
            }
            transform.RotateAround(transform.TransformPoint(rotationPoint), new Vector3(0, 0, 1), 90 * directionSign);
            // || !moveMap.ValidMove() && step < 4
            //�u���b�N���d�Ȃ邩�ASRS�̃X�e�b�v���c���Ă���ꍇ�͌J��Ԃ�
            for (int step = 0; !moveMap.ValidMove() && step < 4; step++)
            {
                //���̈ʒu����step�̓��e�����ړ�������
                transform.position = oldPosition;
                if (rotationType == SuperRotationType.Normal)
                {
                    if (direction == RotationDirection.Left)
                    {
                        transform.position += SRSNormalTypeLeft[step, currentRotation];
                    }
                    else if (direction == RotationDirection.Right)
                    {
                        transform.position += SRSNormalTypeRight[step, currentRotation];
                    }
                }
                else if (rotationType == SuperRotationType.IBlock)
                {
                    if (direction == RotationDirection.Left)
                    {
                        transform.position += SRSNormalTypeIBlockLeft[step, currentRotation];
                    }
                    else if (direction == RotationDirection.Right)
                    {
                        transform.position += SRSNormalTypeIBlockRight[step, currentRotation];
                    }
                }
                re = true;
            }
            //?�F�b�N��ɏd�Ȃ��Ă���ꍇ�͉�?�ł��Ȃ�
            if (!moveMap.ValidMove())
            {
                transform.position = oldPosition;
                transform.rotation = oldRotation;
                currentRotation = oldRotationState;
                re = false;
            }

            return re;
        }
        private void Start()
        {
            moveMap = GetComponent<TetrisMoverInMap>();
        }

    }
}