using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/UsedPositionMap")]
public class TetrisUsedPosition : ScriptableObject
{
    public List<UsedPosition> usedpositionDatas = new List<UsedPosition>();
}

public class UsedPosition
{
    public GameObject prefab;
    public Vector2 position;
}
