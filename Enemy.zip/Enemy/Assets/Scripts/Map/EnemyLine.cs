using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyLine : MonoBehaviour
{
    public GameObject enemyLine;
    public int numEnemyLine = 2;
    public float minDistanceEnemyLine = 1.0f;
    public int bossLinePosition = 15;

    public List<Vector2> usedEnemyLinePositions = new List<Vector2>();

    private bool enemyContact = false;

    void Start()
    {
        LaodPosition();
    }

    void Update()
    {
        BattleStart();
    }

    private void LaodPosition()
    {
        if (DataManager.instance.EventSpaceData.enemyDatas.Count != 0)
        {
            Debug.Log("1num on");

            foreach (var prefabData in DataManager.instance.EventSpaceData.enemyDatas)
            {
                Instantiate(prefabData.enemyLine, prefabData.position, Quaternion.identity);
                usedEnemyLinePositions.Add(prefabData.position);
            }
        }
        else
        {
            Debug.Log("2num on");

            if (DataManager.instance.EventSpaceData.stageClear)
            {
                int cnt = 0;

                while (cnt < numEnemyLine)
                {
                    Vector2 randomPosition = new Vector2(Random.Range(0, 0), Random.Range(3, 15));

                    if (IsPositionValid(randomPosition))
                    {
                        Instantiate(enemyLine, randomPosition, Quaternion.identity);
                        usedEnemyLinePositions.Add(randomPosition);
                        cnt++;

                        EnemyData newData = new EnemyData();
                        newData.position = randomPosition;
                        newData.enemyLine = enemyLine;
                        DataManager.instance.EventSpaceData.enemyDatas.Add(newData);
                    }
                }
                DataManager.instance.EventSpaceData.stageClear = false;
            }
        }
    }

    private bool IsPositionValid(Vector2 position)
    {
        foreach (Vector2 usedPosition in usedEnemyLinePositions)
        {
            if (Vector2.Distance(position, usedPosition) < minDistanceEnemyLine)
            {
                return false;
            }
        }
        return true;
    }

    public void EnemyContact(int y)
    {
        for (int i = 0; i < usedEnemyLinePositions.Count; i++)
        {
            if (y == 1 + usedEnemyLinePositions[i].y)
            {
                usedEnemyLinePositions.RemoveAt(i);
                enemyContact = true;
                DataManager.instance.EventSpaceData.enemyDatas.RemoveAt(i);
            }
        }
    }

    public void BattleStart()
    {
        if (enemyContact == true)
        {
            Time.timeScale = 1.0f;
            int randomEnemyNum = Random.Range(0, DataManager.instance.enemyInformation.enemyINFODatas.Count);

            DataManager.instance.enemyData.enemyHPData
                = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyHPData;

            DataManager.instance.enemyData.enemyFullHPData
                = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyFullHPData;

            DataManager.instance.enemyData.enemyImage
                = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].enemyImage;

            DataManager.instance.enemyData.enemyName
                = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].name;

            DataManager.instance.enemyData.buffInfos
                = DataManager.instance.enemyInformation.enemyINFODatas[randomEnemyNum].buffInfos;

            SceneManager.LoadSceneAsync(2);

            enemyContact = false;
        }
    }
}
