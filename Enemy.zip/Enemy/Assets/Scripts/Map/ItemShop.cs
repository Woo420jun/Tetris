using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemShop : MonoBehaviour
{
    public GameObject Shop;
    public bool openedShop;
    // Start is called before the first frame update
    void Start()
    {
        Shop.SetActive(false);
        openedShop = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
