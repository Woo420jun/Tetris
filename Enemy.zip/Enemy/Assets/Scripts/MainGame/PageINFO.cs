using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using static UnityEditor.Progress;

public class PageINFO : MonoBehaviour
{
    public int randomEnemy;
    public int randomEnemytest;

    void Start()
    {
        GetRandomEnemy();
    }

    public void GetRandomEnemy()
    {
        int randomIndex = Random.Range(0, DataManager.instance.EventSpaceData.eventDatas.Count);
        randomEnemy = randomIndex;

    }
}
