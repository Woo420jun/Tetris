using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundTime : MonoBehaviour
{
    void Start()
    {
        
    }

    public void TimeScalePlus30()
    {
        DataManager.instance.playerTime.playTime += 30;
    }

    public void TimeScalePlus5()
    {
        DataManager.instance.playerTime.playTime += 5;
    }

    public void TimeScaleMinus30()
    {
        DataManager.instance.playerTime.playTime -= 30;
    }

    public void TimeScaleMinus5()
    {
        DataManager.instance.playerTime.playTime -= 5;
    }

}
