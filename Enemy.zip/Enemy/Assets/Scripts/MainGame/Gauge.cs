using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;
using UnityEngine.SceneManagement;

public class Gauge : MonoBehaviour
{
    //Gauge
    public Slider gauge;
    public int mainGaugeMax = 15;
    public int mainGauge = 0;
    public int magnificationGaugeMax = 10;
    public int magnificationGauge = 0;

    public GameObject fill;

    //Skill
    private bool canAttack;
    public bool showSkillTap;
    private bool attacked;

    public GameObject skillTap;
    public GameObject FirstSelect;

    public Text gaugeText;
    public Text costText;
    public Text enemyText;

    public GameObject SkillNum1;
    public GameObject SkillNum2;
    public GameObject SkillNum3;
    public GameObject SkillNum4;

    public Skill skillList;

    public int cost;
    public int skillCost;
    public float attackPower;
    public float defaultValue;
    public float SkillPower;

    //Enemy
    public float enemyHP;
    public float enemyFullHP;

    void Start()
    {
        attackPower = 0;
        gauge.maxValue = mainGaugeMax;
        TetrisManager.Instance.gauge = this;
        attacked = false;
        canAttack = false;
        showSkillTap = false;
        skillTap.SetActive(false);

        UpdateSkills();
        EnemyHPViewer();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            CloseSkillTap();
        }

        gaugeText.text = magnificationGauge + "X";
        costText.text = "COST." + cost;

        GaugeControl();
        CanAttack();

        if(Input.GetKeyDown(KeyCode.P))
        {
            ++cost;
            ++magnificationGauge;
        }// for test
    }

    public void UpdateSkills()
    {
        if (skillList != null && skillList.Skills != null)
        {
            if (SkillNum1 != null)
            {
                Text skillText1 = SkillNum1.GetComponent<Text>();
                if (skillText1 != null && skillList.Skills.Length > 0)
                {
                    SkillInformation skillInfo1 = skillList.Skills[0].GetComponent<SkillInformation>();
                    if (skillInfo1 != null)
                    {
                        skillText1.text = skillInfo1.skillName;
                    }
                }
            }

            if (SkillNum2 != null)
            {
                Text skillText2 = SkillNum2.GetComponent<Text>();
                if (skillText2 != null && skillList.Skills.Length > 1)
                {
                    SkillInformation skillInfo2 = skillList.Skills[1].GetComponent<SkillInformation>();
                    if (skillInfo2 != null)
                    {
                        skillText2.text = skillInfo2.skillName;
                    }
                }
            }

            if (SkillNum3 != null)
            {
                Text skillText3 = SkillNum3.GetComponent<Text>();
                if (skillText3 != null && skillList.Skills.Length > 2)
                {
                    SkillInformation skillInfo3 = skillList.Skills[2].GetComponent<SkillInformation>();
                    if (skillInfo3 != null)
                    {
                        skillText3.text = skillInfo3.skillName;
                    }
                }
            }

            if (SkillNum4 != null)
            {
                Text skillText4 = SkillNum4.GetComponent<Text>();
                if (skillText4 != null && skillList.Skills.Length > 3)
                {
                    SkillInformation skillInfo4 = skillList.Skills[3].GetComponent<SkillInformation>();
                    if (skillInfo4 != null)
                    {
                        skillText4.text = skillInfo4.skillName;
                    }
                }
            }
        }
    }

    public void ActiveSkill1()
    {
        SkillInformation skillInfo1 = skillList.Skills[0].GetComponent<SkillInformation>();

        if (cost >= skillInfo1.skillCost)
        {
            cost -= skillInfo1.skillCost;
            attackPower += skillInfo1.skillPower;
            attackPower *= magnificationGauge;
            enemyHP -= attackPower;
            attackPower = 0;
            attacked = true;

            EnemyHPViewer();

            Debug.Log(enemyHP);
            Debug.Log(attackPower);
            Debug.Log(magnificationGauge);
            Debug.Log(cost);

            if (enemyHP <= 0)
            {
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;
            }
        }
    }

    public void ActiveSkill2()
    {
        SkillInformation skillInfo2 = skillList.Skills[1].GetComponent<SkillInformation>();
        if (cost >= skillInfo2.skillCost)
        {
            cost -= skillInfo2.skillCost;
            attackPower += skillInfo2.skillPower;
            attackPower *= magnificationGauge;
            enemyHP -= attackPower;
            attackPower = 0;
            attacked = true;

            EnemyHPViewer();

            if (enemyHP <= 0)
            {
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;
            }
        }
    }

    public void ActiveSkill3()
    {
        SkillInformation skillInfo3 = skillList.Skills[2].GetComponent<SkillInformation>();
        if (cost >= skillInfo3.skillCost)
        {
            cost -= skillInfo3.skillCost;
            attackPower += skillInfo3.skillPower;
            attackPower *= magnificationGauge;
            enemyHP -= attackPower;
            attackPower = 0;
            attacked = true;

            EnemyHPViewer();

            if (enemyHP <= 0)
            {
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;
            }
        }
    }

    public void ActiveSkill4()
    {
        SkillInformation skillInfo4 = skillList.Skills[3].GetComponent<SkillInformation>();
        if (cost < skillInfo4.skillCost)
        {
            cost -= skillInfo4.skillCost;
            attackPower += skillInfo4.skillPower;
            attackPower *= magnificationGauge;
            enemyHP -= attackPower;
            attackPower = 0;
            attacked = true;

            EnemyHPViewer();

            if (enemyHP <= 0)
            {
                SceneManager.LoadSceneAsync(1);
                Time.timeScale = 1.0f;
            }
        }
    }


    public void CanAttack()
    {
        if (magnificationGauge > 0)
        {
            canAttack = true;
        }

        if (canAttack == true && Input.GetKeyDown(KeyCode.S))
        {
            attackPower = magnificationGauge;
            skillTap.SetActive(true);
            showSkillTap = true;
            EventSystem.current.SetSelectedGameObject(FirstSelect);
        }
    }

    public void OnBreakLine(int deleteCount, int tspinCount)
    {
        mainGauge +=deleteCount;
        
        if (mainGauge>=mainGaugeMax)
        {
            mainGauge-=mainGaugeMax;
            magnificationGauge++;
            cost = mainGaugeMax;
        }
        gauge.value = mainGauge;
    }

    public void GaugeControl()
    {
        if (mainGauge == 0)
        {
            fill.SetActive(false);
        }
        else
        {
            fill.SetActive(true);
        }
    }

    public void CloseSkillTap()
    { 
        skillTap.SetActive(false);
        showSkillTap = false;
        if (attacked == true)
        {
            magnificationGauge = 0;
            attacked = false;
        }
    }

    public void EnemyHPViewer()
    {
        enemyText.text = enemyHP + "/" + enemyFullHP; 
    }
}
