using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TetrisGuide : MonoBehaviour
{
    public GameObject[] tetrisBlocks; 
    private GameObject nextBlock; 
    private Vector3 guidePosition = new Vector3(12, 17, 0); 

    private void Start()
    {
        SpawnNextBlock();
    }

    private void Update()
    {
        if (nextBlock != null)
        {
            nextBlock.transform.position = guidePosition;
        }
    }

    private void SpawnNextBlock()
    {
        int randomIndex = Random.Range(0, tetrisBlocks.Length);
        nextBlock = Instantiate(tetrisBlocks[randomIndex], guidePosition, Quaternion.identity);
    }
}
