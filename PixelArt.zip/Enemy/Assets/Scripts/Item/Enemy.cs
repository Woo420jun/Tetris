using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/EnemyData")]
public class Enemy : ScriptableObject
{
    [SerializeField]
    public int tier;
    public GameObject enemyImage;
    public string enemyName;
    public float enemyFullHPData;
    public float enemyHPData;
    public float enemyDamageData;
    public BuffListData buffInfos;
    public int pageNum;

    public bool isBoss = false;
}
