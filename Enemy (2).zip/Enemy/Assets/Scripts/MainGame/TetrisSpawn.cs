using TetrisControl;
using UnityEngine;
using UnityEngine.SceneManagement;


public class TetrisSpawn : MonoBehaviour
{
    public GameObject gameOver;

    public Transform targetPosition;

    public int[] bagRandomGenerator;
    public int[] bagRandomGeneratorNext;
    public int currentIndex;

    const int NextCount = 3;
    GameObject[] nextBlock = new GameObject[NextCount];

    [SerializeField] Transform[] nextBasis = new Transform[NextCount];

    [SerializeField] TetrisBlockList blockList;
    [SerializeField] TetrisColorSpec colorSpec;

    public GameObject GetNextPrefab(int index)
    {
        if (currentIndex + index >= bagRandomGenerator.Length)
        {
            return blockList.Blocks[bagRandomGeneratorNext[currentIndex + index - bagRandomGenerator.Length]];
        }
        return blockList.Blocks[bagRandomGenerator[currentIndex + index]];
    }

    public void Awake()
    {
        TetrisManager.Instance.spawn = this;
    }
    void Start()
    {

    }

    public void Spawn()
    {
        bagRandomGenerator = new int[blockList.Blocks.Length];
        bagRandomGeneratorNext = new int[blockList.Blocks.Length];
        for (int i = 0; i < bagRandomGenerator.Length; i++)
        {
            bagRandomGenerator[i] = i;
            bagRandomGeneratorNext[i] = i;
        }
        Shuffle();
        Shuffle();
        NewTetris();
        NewTetris();
        NewTetris();
        NewTetris();
    }

    void Shuffle()
    {
        for (int i = 0; i < bagRandomGenerator.Length; i++)
        {
            bagRandomGenerator[i] = bagRandomGeneratorNext[i];
        }
        int n = bagRandomGeneratorNext.Length;
        while (n > 1)
        {
            n--;
            int k = Random.Range(0, n + 1);
            var value = bagRandomGeneratorNext[k];
            bagRandomGeneratorNext[k] = bagRandomGeneratorNext[n];
            bagRandomGeneratorNext[n] = value;
        }
    }

    public GameObject NewTetris()
    {
        GameObject spawn = nextBlock[0];

        nextBlock[0] = nextBlock[1];
        if (nextBlock[0] != null)
        {
            nextBlock[0].transform.position = nextBasis[0].transform.position;
        }
        nextBlock[1] = nextBlock[2];
        if (nextBlock[1] != null)
        {
            nextBlock[1].transform.position = nextBasis[1].transform.position;
        }

        nextBlock[2] = Instantiate(blockList.Blocks[bagRandomGenerator[currentIndex]],
            nextBasis[2].position,
            Quaternion.identity);
        colorSpec.SetColorType(nextBlock[2], Random.Range(0, colorSpec.SpecCount));

        nextBlock[2].GetComponent<TetrisControl.TetrisBlockMover>().enabled = false;

        currentIndex++;
        if (currentIndex >= bagRandomGenerator.Length)
        {
            Shuffle();
            currentIndex = 0;
        }

        if (spawn != null)
        {
            TetrisBlockMover nextMoveBlock = spawn.GetComponent<TetrisBlockMover>();
            spawn.transform.position = GetSpawnPosition(nextMoveBlock.blockType);
            nextMoveBlock.enabled = true;

            if(!nextMoveBlock.ValidMove())
            {
                SceneManager.LoadSceneAsync(2);
                Destroy(spawn);
            }
        }
        return spawn;
    }

    public Vector3 GetSpawnPosition(TetrisBlockMover.BlockType blockType)
    {
        if (blockType == TetrisBlockMover.BlockType.OddNumber)
        {
            return transform.position;
        }
        return transform.position + new Vector3(0.5f, 0.5f, 0);
    }

    public int Triangle(int bottom, int height)
    {
        int answer = bottom * height / 2;
        return answer;
    }
}
