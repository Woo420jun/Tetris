using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/PlayerTime")]
public class PlayerTime : ScriptableObject
{
    public int playTime = 0;
    public int remainTime = 300;
}
