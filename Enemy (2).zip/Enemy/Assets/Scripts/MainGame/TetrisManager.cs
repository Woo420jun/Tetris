public class TetrisManager
{
    static TetrisManager _Instance;
    public static TetrisManager Instance
    {
        get { if(_Instance == null) _Instance = new TetrisManager(); return _Instance; }
    }
    public TetrisBlockHold blockHold;
    public TetrisSpawn spawn;
    public Gauge gauge;
    public TetrisControl.TetrisBlockMover currentBlock;
    public ESC SetESC;
    //public TetrisControl.TetrisMoverInMap currentBlock;
}
