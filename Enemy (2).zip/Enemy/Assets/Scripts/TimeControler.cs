using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeControler : MonoBehaviour
{
    public float timeLate = 3f;
    public bool pause = true;

    void Start()
    {
        Invoke(nameof(UnPause), timeLate);
    }

    private void UnPause()
    {
        pause = false;
        FindAnyObjectByType<TetrisSpawn>().Spawn();
    }
}
