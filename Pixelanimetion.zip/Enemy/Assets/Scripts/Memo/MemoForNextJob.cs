using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MemoForNextJob : MonoBehaviour
{
    //1. Reduce the number of pages one by one during the main game and write a script that will receive damage if it is used up
    //1. apdls rpdla wnddp vpdlwl tnfmf gkskTlr wnfdlrh ek tkdydgkaus vlgofmf qkedmf tn dlTsms tmzmflqxmfmf wkrtjdgkqslek

    //2. Create a game scene to run when the game is out
    //2. rpdla dkdntehldjTdmftl tlfgodgkf rpdlaTlsdmf wpwkr

}
