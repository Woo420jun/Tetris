using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnUsedPosition : MonoBehaviour
{
    public List<Vector2> usedPositions = new List<Vector2>();

    void Start()
    {
        if (DataManager.instance.tetrisUsedposition.usedpositionDatas.Count > 0)
        {
            foreach (var prefabData in DataManager.instance.tetrisUsedposition.usedpositionDatas)
            {
                Instantiate(prefabData.prefab,
                    prefabData.position,
                    Quaternion.identity);
                usedPositions.Add(prefabData.position);
            }
        }
    }
}

