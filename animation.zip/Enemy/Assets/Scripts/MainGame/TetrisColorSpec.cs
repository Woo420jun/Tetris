using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/ColorSpec")]
public class TetrisColorSpec : ScriptableObject
{
    [System.Serializable]
    struct Spec
    {
        [SerializeField]
        Color color;
        public Color Color => color;

        [SerializeField]
        float attack;
        public float Attack => attack;
    }

    [SerializeField]
    Spec[] specList;
    public int SpecCount => specList.Length;

    public void SetColorType(GameObject target, int index)
    {
        foreach (var render in target.GetComponentsInChildren<SpriteRenderer>())
        {
            render.color = specList[index].Color;
        }
    }
}
