using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/PlayerTime")]
public class PlayerTime : ScriptableObject
{
    public float playTime = 0;
    public float remainTime = 300;
    public float MaxTime = 300;
    public float tetrisPlayTime = 0;
}
