using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Player/Player")]
public class Player : ScriptableObject
{
    public float playerHP;
    public float playerMaxHP;
    public float money;

    public string playerName;
}