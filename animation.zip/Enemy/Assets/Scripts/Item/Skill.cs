using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/SkillData")]
public class Skill : ScriptableObject
{
    [SerializeField]
    GameObject[] tetrisBlocks;
    public GameObject[] Skills => tetrisBlocks;

    //public List<ItemData> itemDatas = new List<ItemData>();
}

//public class ItemData
//{
    //public int id;
    //public string name;
    //public int price;
    //public int hpValue;
    //public int moneyValue;
    //public int luckValue;
    //public string description;

    //public Item(int Id, string Name, int Price, int HpValue, int MoneyValue, int LuckValue, string Description)
    //{
    //    id = Id;
    //    name = Name;
    //    price = Price;
    //    hpValue = HpValue;
    //    moneyValue = MoneyValue;
    //    luckValue = LuckValue;
    //    description = Description;
    //}
//}

