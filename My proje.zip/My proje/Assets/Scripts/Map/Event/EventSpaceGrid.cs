using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventSpaceGrid : MonoBehaviour
{

    public static int height = 18;
    public static int width = 13;
    private static Transform[,] grid = new Transform[width, height];

    // Start is called before the first frame update
    void Start()
    {
        AddEventSpaceGrid();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void AddEventSpaceGrid()
    {
        foreach (Transform children in transform)
        {
            int roundedX = Mathf.RoundToInt(children.transform.position.x);
            int roundedY = Mathf.RoundToInt(children.transform.position.y);

            grid[roundedX, roundedY] = children;
            Debug.Log("x = " + roundedX + " " + "y = " + roundedY);
        }
    }

}
