using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public class EventSpace : MonoBehaviour
{
    public GameObject eventSpace;
    public GameObject eventTap;

    public bool openedEventTap;


    // Start is called before the first frame update
    void Start()
    {
        openedEventTap = false;
        eventTap.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        eventTap.SetActive(true);
        openedEventTap=true;
    }

    public void EventActivate()
    {
        if (eventSpace)
        {

        }
    }
}
