using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataManager : MonoBehaviour
{
    public static DataManager instance;
    public EventSpace eventSpace;
    public EventListData EventSpaceData;

    void Awake()
    {
        if (instance == null) 
        {
            instance = this;
        }
    }

}
