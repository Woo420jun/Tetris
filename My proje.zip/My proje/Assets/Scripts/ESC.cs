using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ESC : MonoBehaviour
{
    public GameObject ESCTap;
    public GameObject FirstSelect;
    public bool showEscMenu;

    void Start()
    {
        ESCTap.SetActive(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if(showEscMenu)
            {
                ResumeGame();
            }
            else
            {
                StoppedGame();
            }
        }
    }

    public void StoppedGame()
    {
        EventSystem.current.SetSelectedGameObject(FirstSelect); 
        ESCTap.SetActive(true);
        Time.timeScale = 0f;
        showEscMenu = true;
    }

    public void ResumeGame()
    {
        ESCTap.SetActive(false);
        Time.timeScale = 1f;
        showEscMenu= false;
    }
}
