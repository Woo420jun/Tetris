using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TetrisShadow : MonoBehaviour
{
    public static int height = 23;
    public static int width = 10;
    public static Transform[,] grid = new Transform[width, height];

    public const float blockMove = 1f;

    void Start()
    {
        PopulateGridFromData();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) ||
                Input.GetKeyDown(KeyCode.RightArrow) ||
                Input.GetKeyDown(KeyCode.Z) ||
                Input.GetKeyDown(KeyCode.X))
        {
            Debug.Log("Destroying shadow object.");
            Destroy(gameObject);
        }
        //HardDrop();
    }

    void ShadowHardDrop()
    {
        while (true)
        {
            transform.position += new Vector3(0, -blockMove, 0);
            if (ValidMove())
            {
                transform.position -= new Vector3(0, -blockMove, 0);

                this.enabled = false;
                break;
            }
        }
    }

    public bool ValidMove()
    {
        foreach (Transform children in transform)
        {
            int roundedX = Mathf.RoundToInt(children.transform.position.x);
            int roundedY = Mathf.RoundToInt(children.transform.position.y);

            if (roundedX < 0 || roundedX >= width || roundedY < 0 || roundedY >= height)
            {
                return false;
            }
            if (grid[roundedX, roundedY] != null)
            {
                return false;
            }
        }
        return true;
    }

    void PopulateGridFromData()
    {
        if (DataManager.instance.EventSpaceData.tetrisBlockPositionDatas.Count > 0)
        {
            foreach (var prefabData in DataManager.instance.EventSpaceData.tetrisBlockPositionDatas)
            {
                if (prefabData.prefab == null)
                {
                    Debug.LogWarning("Prefab is not assigned in prefabData.");
                    continue; // Skip this iteration if prefab is null
                }

                // Convert position from Vector2 to grid indices
                int x = Mathf.RoundToInt(prefabData.position.x);
                int y = Mathf.RoundToInt(prefabData.position.y);

                // Check bounds to avoid index out of range errors
                if (x >= 0 && x < width && y >= 0 && y < height)
                {
                    // Place the prefab in the grid
                    if (grid[x, y] == null)
                    {
                        // Create a new GameObject instance for the prefab
                        Transform prefabInstance = Instantiate(prefabData.prefab.transform, new Vector3(x, y, 0), Quaternion.identity);
                        grid[x, y] = prefabInstance; // Assign to grid
                    }
                    else
                    {
                        Debug.LogWarning($"Grid position ({x}, {y}) is already occupied.");
                    }
                }
                else
                {
                    Debug.LogWarning($"Position ({x}, {y}) is out of grid bounds.");
                }
            }
        }
    }
}
