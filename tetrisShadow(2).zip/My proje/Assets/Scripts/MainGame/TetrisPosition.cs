using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/TetrisPositionData")]

public class TetrisPosition : ScriptableObject
{
    public List<TetrisPositionData> tetrisPositionData = new List<TetrisPositionData>();
}

public class TetrisPositionData
{
    public GameObject tetrisBlock;
    public Vector2 position;
}
