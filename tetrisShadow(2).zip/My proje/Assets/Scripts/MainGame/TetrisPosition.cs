using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/TetrisPositionData")]

public class TetrisPosition : ScriptableObject
{
    public List<TetrisPositionData> tetrisPositionDatas = new List<TetrisPositionData>();
}

public class TetrisPositionData
{
    public int width, height;
}
