using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TetrisControl
{
    public class TetrisMoverInMap : MonoBehaviour
    {
        public Vector3 rotationPoint;

        //movePower
        public const float blockMove = 1f;

        //TetrisSRS
        public enum BlockType
        {
            OddNumber,
            EvenNumber,
        }
        public BlockType blockType;
        public MapTetrisSRS tetrisSRS;

        //drop
        private float previousTime;
        private float fallTime = 2f;
        public float hardDropSpeed = 20f;

        //map
        public static int height = 18;
        public static int width = 13;
        private static Transform[,] grid = new Transform[width, height];
        
        //HOLD
        private bool isMoving = false;
        private bool isHolding = false;
        const float holdDelayLoop = 0.15f;
        const float holdLoop = 0.05f;
        private float holdDelay = holdDelayLoop;

        private float holdTime = 0f;

        //Delay
        private bool ADF = true;
        private bool SDF = true;
        private bool delayTimeRunning = false;

        private float delay = 1f;
        private float delayTime = 0f;

        private float delayLoop = 0.05f;
        private float delayLoopTime = 0f;


        private MapESC esc;


        void Start()
        {
            tetrisSRS = GetComponent<MapTetrisSRS>();
            esc = FindObjectOfType<MapESC>();
        }

        void Update()
        {
            if (!esc.showEscMenu)
            {
                Hold();
                HoldDownKey();

                //drop
                if (Input.GetKeyDown(KeyCode.UpArrow))
                {
                    HardDrop();
                }
                if (Input.GetKeyDown(KeyCode.DownArrow))
                {
                    transform.position += new Vector3(0, -blockMove, 0);
                    previousTime = Time.time;
                    if (!ValidMove())
                    {
                        transform.position -= new Vector3(0, -blockMove, 0);
                        AddToGrid();
                        CheckForLines();

                        this.enabled = false;
                        //TetrisManager.Instance.spawn.NewTetris();
                        FindObjectOfType<MapSpawn>().NewTetris();

                        return;
                    }
                }
                if (Input.GetKey(KeyCode.DownArrow))
                {
                    DownArrowMove();
                }
                if (Time.time - previousTime > fallTime && ADF)
                {
                    transform.position += new Vector3(0, -blockMove, 0);
                    previousTime = Time.time;
                    if (!ValidMove())
                    {
                        transform.position -= new Vector3(0, -blockMove, 0);
                        AddToGrid();
                        CheckForLines();

                        this.enabled = false;
                        //TetrisManager.Instance.spawn.NewTetris();
                        FindObjectOfType<MapSpawn>().NewTetris();

                    }
                }

                MoveRightLeftTurn();

                if (delayTimeRunning)
                {
                    delayTime += Time.deltaTime;
                    if (delayTime >= delay)
                    {
                        delayTime = 0f;
                        delayTimeRunning = false;
                        ADF = true;
                        previousTime = Time.time;

                        transform.position += new Vector3(0, -blockMove, 0);
                        if (!ValidMove())
                        {
                            transform.position -= new Vector3(0, -blockMove, 0);

                            AddToGrid();
                            CheckForLines();

                            this.enabled = false;
                            //TetrisManager.Instance.spawn.NewTetris();
                            FindObjectOfType<MapSpawn>().NewTetris();

                        }
                    }
                }
            }
        }

        void Hold()
        {
            if (Input.GetKey(KeyCode.RightArrow) && Input.GetKey(KeyCode.LeftArrow))
            {
                holdTime = 0f;
                holdDelay = holdDelayLoop;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                holdTime += Time.deltaTime;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                holdTime += Time.deltaTime;
            }
            else
            {
                holdTime = 0f;
                holdDelay = holdDelayLoop;
            }
        }

        void HoldDownKey()
        {
            if (Input.GetKey(KeyCode.DownArrow))
            {
                delayLoopTime += Time.deltaTime;
            }
            else
            {
                delayLoopTime = 0f;
            }
        }

        void MoveRightLeftTurn()
        {
            if (Input.GetKeyDown(KeyCode.LeftArrow) ||
                (holdTime >= holdDelay && Input.GetKey(KeyCode.LeftArrow)))
            {
                if (holdTime >= holdDelay)
                {
                    holdTime = 0.0f;
                    holdDelay = holdLoop;
                }
                transform.position += new Vector3(-blockMove, 0, 0);
                if (!ValidMove())
                    transform.position -= new Vector3(-blockMove, 0, 0);
            }
            else if (Input.GetKeyDown(KeyCode.RightArrow) ||
                (holdTime >= holdDelay && Input.GetKey(KeyCode.RightArrow)))
            {
                if (holdTime >= holdDelay)
                {
                    holdTime = 0.0f;
                    holdDelay = holdLoop;
                }
                transform.position += new Vector3(blockMove, 0, 0);
                if (!ValidMove())
                    transform.position -= new Vector3(blockMove, 0, 0);
            }

            //turn
            else if (Input.GetKeyDown(KeyCode.Z))
            {
                if (tetrisSRS.SRSTetrisBlock(MapTetrisSRS.RotationDirection.Left))
                {
                    previousTime = Time.time;
                }
            }
            else if (Input.GetKeyDown(KeyCode.X))
            {
                if (tetrisSRS.SRSTetrisBlock(MapTetrisSRS.RotationDirection.Right))
                {
                    previousTime = Time.time;
                }
            }
        }

        void DownArrowMove()
        {
            if (delayLoop < delayLoopTime)
            {
                delayLoopTime = 0f;
                transform.position += new Vector3(0, -blockMove, 0);
                previousTime = Time.time;
            }
            
            if (!ValidMove())
            {
                delayTimeRunning = true;
                ADF = false;
                transform.position -= new Vector3(0, -blockMove, 0);
            }
        }

        void SoftDrop()
        {
            if(!ADF)
            {
                delayTime += Time.deltaTime;
                SDF = false;
                if (delay < delayTime)
                {
                    ADF = true;
                    delayTime = 0f;
                }
            }
        }

        void HardDrop()
        {
            while (true)
            {
                transform.position += new Vector3(0, -blockMove, 0);
                if (!ValidMove())
                {
                    transform.position -= new Vector3(0, -blockMove, 0);

                    AddToGrid();
                    CheckForLines();

                    this.enabled = false;
                    //TetrisManager.Instance.spawn.NewTetris();
                    FindObjectOfType<MapSpawn>().NewTetris();
                    break;
                }
            }
            previousTime = Time.time;
        }

        void CheckForLines()
        {
            for (int i = height - 1; i >= 0; i--)
            {
                if (HasLine(i))
                {
                    Buff(i);
                }
            }
        }

        bool HasLine(int i)
        {
            for (int j = 0; j < width; j++)
            {
                if (grid[j, i] == null)
                    return false;
            }

            return true;
        }

        void Buff(int i)
        {

        }

        void AddToGrid()
        {
            foreach (Transform children in transform)
            {
                int roundedX = Mathf.RoundToInt(children.transform.position.x);
                int roundedY = Mathf.RoundToInt(children.transform.position.y);

                grid[roundedX, roundedY] = children;
                DataManager.instance.eventSpace.EventActivate(roundedX, roundedY);
                DataManager.instance.enemyLine.EnemyContact(roundedY);
            }
        }

        public bool ValidMove()
        {
            foreach (Transform children in transform)
            {
                int roundedX = Mathf.RoundToInt(children.transform.position.x);
                int roundedY = Mathf.RoundToInt(children.transform.position.y);

                if (roundedX < 0 || roundedX >= width || roundedY < 0 || roundedY >= height)
                {
                    return false;
                }
                if (grid[roundedX, roundedY] != null)
                {
                    return false;

                }
            }

            return true;
        }
    }
}
