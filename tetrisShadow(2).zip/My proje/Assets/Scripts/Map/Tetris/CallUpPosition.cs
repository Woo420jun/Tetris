using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CallUpPosition : MonoBehaviour
{
    void Start()
    {
        if (DataManager.instance.EventSpaceData.mapTetrisBlockPositionDatas.Count > 0)
        {
            foreach (var prefabData in DataManager.instance.EventSpaceData.mapTetrisBlockPositionDatas)
            {
                if (prefabData.prefab != null)
                {
                    Debug.Log(prefabData.position);
                    Instantiate(prefabData.prefab, prefabData.position, Quaternion.identity);
                }
                else
                {
                    Debug.Log(prefabData.position);
                    Debug.LogWarning("Prefab is null for position: " + prefabData.position);
                }
            }
        }
    }
}
