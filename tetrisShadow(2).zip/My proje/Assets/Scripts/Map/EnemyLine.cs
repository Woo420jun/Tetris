using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyLine : MonoBehaviour
{
    public GameObject enemyLine;
    public int numEnemyLine = 2;
    public float minDistanceEnemyLine = 1.0f;

    public List<Vector2> usedEnemyLinePositions = new List<Vector2>();

    private bool enemyContact = false;

    void Start()
    {
        LaodPosition();
    }

    void Update()
    {
        BattleStart();
    }

    private void LaodPosition()
    {
        if (DataManager.instance.EventSpaceData.enemyDatas.Count > 0)
        {
            foreach (var prefabData in DataManager.instance.EventSpaceData.enemyDatas)
            {
                Instantiate(prefabData.enemyLine, prefabData.position, Quaternion.identity);
                usedEnemyLinePositions.Add(prefabData.position);
            }
        }
        else
        {
            int cnt = 0;

            while (cnt < numEnemyLine)
            {
                Vector2 randomPosition = new Vector2(Random.Range(0, 0), Random.Range(14, 15));

                if (IsPositionValid(randomPosition))
                {
                    Instantiate(enemyLine, randomPosition, Quaternion.identity);
                    usedEnemyLinePositions.Add(randomPosition);
                    cnt++;

                    EnemyData newData = new EnemyData();
                    newData.position = randomPosition;
                    newData.enemyLine = enemyLine;
                    DataManager.instance.EventSpaceData.enemyDatas.Add(newData);
                }
            }
        }
    }

    private bool IsPositionValid(Vector2 position)
    {
        foreach (Vector2 usedPosition in usedEnemyLinePositions)
        {
            if (Vector2.Distance(position, usedPosition) < minDistanceEnemyLine)
            {
                return false;
            }
        }
        return true;
    }

    public void EnemyContact(int y)
    {
        for (int i = 0; i < usedEnemyLinePositions.Count; i++)
        {
            if (y > usedEnemyLinePositions[i].y)
            {
                Debug.Log("enemy contact");
                usedEnemyLinePositions.RemoveAt(i);
                enemyContact = true;
            }
        }
    }

    public void BattleStart()
    {
        if (enemyContact == true)
        {
            Debug.Log("enemy!!");
            SceneManager.LoadSceneAsync(2);
            Time.timeScale = 1.0f;

            enemyContact = false;
        }
    }
}
