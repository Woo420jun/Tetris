using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyInformation : MonoBehaviour
{
    public float enemyFullHP;
    public float enemyHP;
    public GameObject enemyImage;

    void Start()
    {

    }

    void Update()
    {

    }
}
