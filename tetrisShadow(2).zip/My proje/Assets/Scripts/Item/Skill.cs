using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Tetris/SkillData")]
public class Skill : ScriptableObject
{
    [SerializeField]
    GameObject[] tetrisBlocks;
    public GameObject[] Skills => tetrisBlocks;

}

