using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FinalScore : MonoBehaviour
{

    public int finalScore; 
    private bool score = false;
    private float scoreUp = 0f;
    public float scoreUpSpeed = 0f;

    public GameObject finalScorePanel;

    public GameObject mainMenuButton;
    public GameObject ExitGameButton;

    void Start()
    {
        
    }

    void Update()
    {
        scoreUp = scoreUpSpeed * Time.time;

        ButtonSetting();
    }

    void ScoreUp()
    {
        if (scoreUp>=finalScore)
        {
            
        }
    }

    void ButtonSetting()
    {
        if (score = true)
        {
            mainMenuButton.SetActive(true);
            ExitGameButton.SetActive(true);
        }    
    }
}
