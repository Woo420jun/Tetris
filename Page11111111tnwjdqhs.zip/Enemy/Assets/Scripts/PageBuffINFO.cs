using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EnemyBuffInfo
{
    public int damageBuffPlus;
    public int damageBuffMultiply;
    public int damageBuffPercent;

    public int costBuffPlus;
    public int costBuffMultiply;
    public int costBuffPercent;

    public int HPBuffPlus;
    public int HPBuffMultiply;
    public int HPBuffPercent;

    public string buffName;
    public string buffEffect;
}

[System.Serializable]
public class EnemyDeBuffInfo
{
    public int damageDebuffMinus;
    public int damageDebuffDivide;
    public int damageDebuffPercent;

    public int costDebuffMinus;
    public int costDebuffDivide;
    public int costDebuffPercent;

    public int HPDebuffMinus;
    public int HPDebuffDivide;
    public int HPDebuffPercent;

    public string deBuffName;
    public string deBuffEffect;
}


[CreateAssetMenu(menuName = "Page/PageBuff")]
public class PageBuffINFO : ScriptableObject
{
    //public List<EnemyBuffInfo> buffInfoDatas = new List<EnemyBuffInfo>();
    //public List<EnemyDeBuffInfo> deBuffInfoDatas = new List<EnemyDeBuffInfo>();

    //buff
    public int damageBuffPlus;
    public int damageBuffMultiply;
    public int damageBuffPercent;

    public int costBuffPlus;
    public int costBuffMultiply;
    public int costBuffPercent;

    public int HPBuffPlus;
    public int HPBuffMultiply;
    public int HPBuffPercent;

    public string buffName;
    public string buffEffect;

    //debuff
    public int damageDebuffMinus;
    public int damageDebuffDivide;
    public int damageDebuffPercent;

    public int costDebuffMinus;
    public int costDebuffDivide;
    public int costDebuffPercent;

    public int HPDebuffMinus;
    public int HPDebuffDivide;
    public int HPDebuffPercent;

    public string deBuffName;
    public string deBuffEffect;

    public void DataClear()
    {
        damageBuffPlus = 0;
        damageBuffMultiply = 0;
        damageBuffPercent = 0;

        costBuffPlus = 0;
        costBuffMultiply = 0;
        costBuffPercent = 0;

        HPBuffPlus = 0;
        HPBuffMultiply = 0;
        HPBuffPercent = 0;

        buffName = null;
        buffEffect = null;

        damageDebuffMinus = 0;
        damageDebuffDivide = 0;
        damageDebuffPercent = 0;

        costDebuffMinus = 0;
        costDebuffDivide = 0;
        costDebuffPercent = 0;

        HPDebuffMinus = 0;
        HPDebuffDivide = 0;
        HPDebuffPercent = 0;

        deBuffName = null;
        deBuffEffect = null;
    }
}
