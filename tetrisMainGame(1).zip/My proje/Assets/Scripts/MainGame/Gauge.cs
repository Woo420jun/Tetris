using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gauge : MonoBehaviour
{
    public Slider gauge;
    public int mainGaugeMax = 15;
    public int mainGauge = 0;
    public int magnificationGaugeMax = 10;
    public int magnificationGauge = 0;

    void Start()
    {
        gauge.maxValue = mainGaugeMax;
        TetrisManager.Instance.gauge = this;
    }

    void Update()
    {
        
    }

    public void CanAttack()
    {

    }

    public void OnBreakLine(int deleteCount, int tspinCount)
    {
        mainGauge +=deleteCount;
        
        if (mainGauge>=mainGaugeMax)
        {
            mainGauge-=mainGaugeMax;
            magnificationGauge++;
        }
        gauge.value = mainGauge;
    }
}
