using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemDataBase : MonoBehaviour
{
    public static List<Item> itemList = new List<Item> ();

    void Awake ()
    {
        itemList.Add(new Item(0, "None", 0, 0, 0, 0, "None"));// ID, Name, , , ItemDescriotion
        itemList.Add(new Item(1, "None", 0, 0, 0, 0, "None"));
        itemList.Add(new Item(2, "None", 0, 0, 0, 0, "None"));
        itemList.Add(new Item(3, "None", 0, 0, 0, 0, "None"));
        itemList.Add(new Item(4, "None", 0, 0, 0, 0, "None"));
    }
}
